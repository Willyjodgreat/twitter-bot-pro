const { chromium } = require('playwright');
const fs = require('fs');
const readline = require('readline');

(async () => {
  console.log('📱 LOGIN USING PHONE HOTSPOT (NEW IP)');
  console.log('======================================\n');
  
  const browser = await chromium.launch({ 
    headless: false,
    args: ['--no-sandbox']
  });
  
  const page = await browser.newPage();
  
  // Go to REGULAR Twitter (not mobile.x.com)
  await page.goto('https://twitter.com/login');
  await page.waitForTimeout(3000);
  
  console.log('⚠️  CRITICAL: Use "Continue with Google" if available!');
  console.log('Google login bypasses IP restrictions.\n');
  
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  await new Promise(resolve => {
    rl.question('Press Enter ONLY after seeing your HOME PAGE with tweets: ', () => {
      rl.close();
      resolve();
    });
  });
  
  // Save session
  const context = page.context();
  await context.storageState({ path: 'twitter_session.json' });
  await browser.close();
  
  console.log('\n✅ Session saved from clean mobile IP!');
  console.log('🔁 Now switch back to home WiFi and run: npm start');
})();
