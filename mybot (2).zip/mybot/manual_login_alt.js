const { chromium } = require('playwright');
const fs = require('fs');
const readline = require('readline');

(async () => {
  console.log('🚀 Alternative Twitter Login Helper');
  console.log('====================================\n');
  
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  const browser = await chromium.launch({ 
    headless: false,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-blink-features=AutomationControlled'
    ]
  });
  
  // Use MOBILE user agent to bypass restrictions
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 }, // iPhone 12 Pro size
    userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1'
  });
  
  const page = await context.newPage();
  
  console.log('📱 Using mobile mode to bypass restrictions...');
  console.log('\n=== IMPORTANT NOTES ===');
  console.log('1. This uses MOBILE Twitter (easier login)');
  console.log('2. Try BOTH methods:');
  console.log('   a) Email/phone + password');
  console.log('   b) "Continue with Google" button');
  console.log('3. Complete ALL verifications if asked');
  console.log('4. Wait until you see tweets in timeline\n');
  
  // Use mobile.twitter.com which often has fewer restrictions
  await page.goto('https://mobile.twitter.com/login', {
    waitUntil: 'networkidle',
    timeout: 30000
  });
  
  await page.waitForTimeout(3000);
  
  console.log('✅ Login page loaded!');
  console.log('\n🎯 START LOGGING IN NOW!');
  
  // Wait for manual completion
  await new Promise(resolve => {
    rl.question('\n⏳ Press Enter ONLY AFTER you are fully logged in and see tweets: ', () => {
      rl.close();
      resolve();
    });
  });
  
  console.log('\n🔍 Verifying login...');
  await page.waitForTimeout(5000);
  
  // Check if logged in by trying to access home
  await page.goto('https://mobile.twitter.com/home', {
    waitUntil: 'domcontentloaded',
    timeout: 15000
  });
  
  await page.waitForTimeout(3000);
  
  // Save session if successful
  try {
    // Check for logged-in indicators
    const loggedIn = await page.evaluate(() => {
      return document.querySelector('[data-testid="tweet"]') !== null ||
             document.body.innerText.includes('Home') ||
             window.location.href.includes('home');
    });
    
    if (loggedIn) {
      await context.storageState({ path: 'twitter_session.json' });
      console.log('\n🎉 SUCCESS! Session saved to twitter_session.json');
      
      // Show session info
      if (fs.existsSync('twitter_session.json')) {
        const sessionData = JSON.parse(fs.readFileSync('twitter_session.json', 'utf8'));
        console.log(`🍪 ${sessionData.cookies.length} cookies saved`);
      }
    } else {
      console.log('\n⚠️  Not fully logged in. Trying desktop version...');
      
      // Try desktop version as fallback
      await page.goto('https://twitter.com/home', {
        waitUntil: 'domcontentloaded',
        timeout: 15000
      });
      
      await page.waitForTimeout(3000);
      
      const desktopLoggedIn = await page.evaluate(() => {
        return document.querySelector('[data-testid="tweetTextarea_0"]') !== null;
      });
      
      if (desktopLoggedIn) {
        await context.storageState({ path: 'twitter_session.json' });
        console.log('✅ Desktop login successful! Session saved.');
      } else {
        console.log('❌ Login verification failed.');
        console.log('Saving debug screenshot...');
        await page.screenshot({ path: 'login_debug.png' });
      }
    }
  } catch (error) {
    console.log('❌ Error:', error.message);
  }
  
  console.log('\n⏳ Closing browser in 3 seconds...');
  await page.waitForTimeout(3000);
  
  await browser.close();
  
  console.log('\n=== NEXT STEPS ===');
  if (fs.existsSync('twitter_session.json')) {
    console.log('1. Run: npm start');
    console.log('2. Bot will use the new session');
  } else {
    console.log('1. Check login_debug.png for clues');
    console.log('2. Wait 1-2 hours and try again');
    console.log('3. Try from a different network if possible');
  }
})();
