// stealth_login.js - Complete fingerprint rotation
const { chromium } = require('playwright');
const fs = require('fs');
const readline = require('readline');

(async () => {
  console.log('🕵️‍♂️ STEALTH MODE: Twitter Login');
  console.log('===============================\n');
  
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  // RANDOMIZED browser fingerprint - changes every time
  const userAgents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1'
  ];
  
  const viewports = [
    { width: 1920, height: 1080 },
    { width: 1366, height: 768 },
    { width: 1536, height: 864 },
    { width: 390, height: 844 } // Mobile
  ];
  
  // Pick random fingerprint
  const randomUA = userAgents[Math.floor(Math.random() * userAgents.length)];
  const randomVP = viewports[Math.floor(Math.random() * viewports.length)];
  
  console.log(`🖥️  Using: ${randomUA.includes('Mobile') ? 'Mobile' : 'Desktop'} fingerprint`);
  
  const browser = await chromium.launch({ 
    headless: false,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-blink-features=AutomationControlled',
      '--disable-features=IsolateOrigins,site-per-process',
      '--disable-web-security', // Temporarily for testing
      '--disable-site-isolation-trials'
    ]
  });
  
  // CRITICAL: Use isolated browser profile
  const context = await browser.newContext({
    userDataDir: './browser_profile',
    viewport: randomVP,
    userAgent: randomUA,
    locale: 'en-US',
    timezoneId: 'America/New_York',
    permissions: ['geolocation']
  });
  
  // Add stealth scripts to hide automation
  await context.addInitScript(() => {
    // Hide webdriver
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
    
    // Mock plugins
    Object.defineProperty(navigator, 'plugins', {
      get: () => [{
        name: 'Chrome PDF Plugin',
        filename: 'internal-pdf-viewer',
        description: 'Portable Document Format'
      }, {
        name: 'Chrome PDF Viewer',
        filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai',
        description: 'Portable Document Format'
      }]
    });
    
    // Mock Chrome
    window.chrome = { runtime: {}, loadTimes: () => {} };
    
    // Override permissions
    const originalQuery = window.navigator.permissions.query;
    window.navigator.permissions.query = (parameters) => (
      parameters.name === 'notifications' ?
        Promise.resolve({ state: Notification.permission }) :
        originalQuery(parameters)
    );
  });
  
  const page = await context.newPage();
  
  console.log('\n🎯 STRATEGY: Use DIFFERENT login method than before');
  console.log('====================================================');
  console.log('If last account used Email/Password, try:');
  console.log('1. "Continue with Google" button');
  console.log('2. Phone number login');
  console.log('3. Username instead of email');
  console.log('\n⏳ Adding random delays to appear human...');
  
  // Go to login with random delays
  await page.waitForTimeout(2000 + Math.random() * 3000);
  
  // Try ALTERNATIVE login URL
  const loginUrls = [
    'https://twitter.com/i/flow/login?redirect_after_login=%2F',
    'https://twitter.com/login',
    'https://x.com/i/flow/login',
    'https://mobile.twitter.com/login'
  ];
  
  const randomUrl = loginUrls[Math.floor(Math.random() * loginUrls.length)];
  console.log(`🌐 Using URL: ${randomUrl}`);
  
  await page.goto(randomUrl, {
    waitUntil: 'networkidle',
    timeout: 30000
  });
  
  await page.waitForTimeout(3000 + Math.random() * 2000);
  
  console.log('\n✅ Page loaded!');
  console.log('\n=== CRITICAL INSTRUCTIONS ===');
  console.log('1. Use a DIFFERENT login method than before');
  console.log('2. Complete ALL verifications (CAPTCHA, email code, etc.)');
  console.log('3. Wait until you see your HOME TIMELINE with tweets');
  console.log('4. If stuck, try the OTHER login option on the page');
  
  await new Promise(resolve => {
    rl.question('\n⏳ Press Enter ONLY after FULLY logged in (seeing tweets): ', () => {
      rl.close();
      resolve();
    });
  });
  
  console.log('\n🔍 Verifying login with multiple checks...');
  
  // Try multiple verification methods
  let loggedIn = false;
  
  for (let i = 0; i < 3; i++) {
    await page.waitForTimeout(2000);
    
    loggedIn = await page.evaluate(() => {
      return document.querySelector('[data-testid="tweet"]') !== null ||
             document.querySelector('[data-testid="tweetTextarea_0"]') !== null ||
             document.body.innerText.includes('Home') ||
             window.location.href.includes('/home');
    });
    
    if (loggedIn) break;
    
    // Try different pages
    const checkPages = ['https://twitter.com/home', 'https://x.com/home'];
    for (const url of checkPages) {
      try {
        await page.goto(url, { timeout: 10000 });
        await page.waitForTimeout(2000);
      } catch (e) {}
    }
  }
  
  if (loggedIn) {
    await context.storageState({ path: 'twitter_session.json' });
    console.log('\n🎉 SUCCESS! Stealth session created.');
    
    // Show fingerprint used
    console.log(`📊 Fingerprint used:`);
    console.log(`   User-Agent: ${randomUA.substring(0, 60)}...`);
    console.log(`   Viewport: ${randomVP.width}x${randomVP.height}`);
  } else {
    console.log('\n❌ Login verification failed.');
    console.log('📸 Saving debug info...');
    await page.screenshot({ path: 'stealth_debug.png', fullPage: true });
    
    console.log('\n💡 POSSIBLE SOLUTIONS:');
    console.log('1. Wait 2-4 hours (IP cool-down)');
    console.log('2. Use a different network (phone hotspot)');
    console.log('3. Create session on VPS instead');
  }
  
  console.log('\n⏳ Closing in 3 seconds...');
  await page.waitForTimeout(3000);
  await browser.close();
})();
